

const animeItems = document.querySelectorAll('.anim');

if (animeItems.length > 0){
    window.addEventListener('scroll', animOnScroll);
    function animOnScroll() {
        for (let index = 0; index < animeItems.length; index++){
            const animeItem = animeItems[index];
            const animeItemHeight = animeItem.offsetHeight;
            const animeItemOffset = offset(animeItem).top;
            const animeStart = 4;

            let animeItemPoint = window.innerHeight - animeItemHeight / animeStart;
            if (animeItemHeight > window.innerHeight){
                animeItemPoint = window.innerHeight - window.innerHeight / animeStart;
            }

            if ((window.pageYOffset > animeItemOffset - animeItemPoint) && window.pageYOffset < (animeItemOffset + animeItemHeight)) {
                animeItem.classList.add('active');
            } else {
                if (!animeItem.classList.contains('anim-no')){
                    animeItem.classList.remove('active')
                }
            }

        }
    function offset(el) {
        const rect = el.getBoundingClientRect(),
            scrollleft = window.pageXOffset || document.documentElement.scrollLeft,
            scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        return {top: rect.top + scrollTop, left: rect.left + scrollleft}
    }

    }
    setTimeout(() => {
        animOnScroll(); 
    }, 300);
}
var phr = new Array();

    phr.push("./photos/kultura3.jpeg");

    phr.push("./photos/kultura4.jpeg");

    phr.push("./photos/kultura2.jpeg");

function Rotator_cont() {

var s = 5000;  // Время отображения

var N=phr.length;

var i=Math.round(Math.random()*(N));Rotator(i);

 

function Rotator(i){

i++; if(i>N-1){i=0};//alert(i);

document.querySelector('.home-wrapper').style.backgroundImage='url('+phr[i]+')';

timerId01=setTimeout(function(){Rotator(i)},s);return;}

}Rotator_cont()

var counter = 0

document.querySelector('.sun-moon').addEventListener('click', function(){
    counter+=1
    if (counter % 2 == 0) {
        document.body.style.backgroundColor = 'white'
        document.body.style.color = 'black'
        document.querySelector('.sun-moon').innerHTML = '<img class="time su" src="./photos/free-icon-font-sun-5068870.png" alt="">';
        document.querySelector('.card-button').classList.remove('night');
    }else{
        document.body.style.backgroundColor = '#222'
        document.body.style.color = 'white'
        document.querySelector('.sun-moon').innerHTML = '<img class="time sun" src="./photos/free-icon-font-moon-5527884.png" alt="">';
        document.querySelector('.card-button').classList.add('night');
        
    }
})

